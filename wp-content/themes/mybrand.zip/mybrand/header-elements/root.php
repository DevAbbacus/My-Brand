<div class="whb-main-header">
	<?php echo apply_filters( 'woodmart_header_builder_root_children', $children ); ?>
</div>
